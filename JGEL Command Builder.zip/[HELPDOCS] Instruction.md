# [HELPDOCS] Instruction

Instructions are classes added to the JGELConsole, which can be accessed via a terminal. (i.e java the runtime terminal.)

For an instruction to be usable within the console, it must be added to it;
```Java
JGELConsole.AddInstruction(JGELConsoleInstruction)
```

A JGEL instruction consists of two sections;

## instruction container
The JGELConsoleInstruction interface is implemented in a container for the entire instruction - which is actually accessed like a programme; type the name to open it up.

This container is intended to contain switches for whatever the the container is controlling.

For example, the Thread instruction in JGEL (Container: INSTThread). It is a container which controlls threads in multiple ways (kill, list, etc.).

Operation of a command from the console is intendended to follow accross multiple lines, like this:

```
> InstructionName
> SwitchName
> [Any parameters requested by the switch script.]
```


## switches
Switches are small scripts written within in the instruction class, and are the active part of the instruction to perform actions.

It's best practice for switches to call a routine or method, but the switches may contain a more elaborate script.

Imports required for reffering to your own classes is supported within the instruction creation tool.

# Naming Convention

Instruction names themselves in the terminal are not case sensitive. The console interprets them in lowercase, for this reason name definitions within the container must be lower case.

The instruction name for the terminal may contain spaces and grammar, but it's strongly advised you keep it short, simple, and use camel casing.

The instruction container class should follow the convention:
```
INST[name]
i.e INSTPlayer
```
This does not define what is typed to access it, that is only changed with the name definition within the class.


# Brief Help
a simple, one line description of the entire container, i.e
```
Controlls for the player's inventory
```

# Help
larger help documentation. Should at least document each switch, with a description of them at least.

# Parse
Method entered when the user first opens the instruction within the terminal. this method does not return untill the instruction is complete, i.e when the user has picked a switch, entered parameters, and the script has completed,